package com.example.bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.SparseArray
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlin.math.*
import kotlin.collections.List

class DiscoverDevices : AppCompatActivity() {

    private lateinit var arrayAdapter: ArrayAdapter<String>
    private lateinit var stringArrayList: ArrayList<String>
    private var t = LeDeviceListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_discover_devices)

        val scanButton: Switch = findViewById(R.id.scan)
        val deviceList: ListView = findViewById(R.id.listView)
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                1
            )
            return
        }

        stringArrayList = ArrayList()
        arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, stringArrayList)
        deviceList.adapter = arrayAdapter

        scanButton.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                bluetoothAdapter.startDiscovery()
            } else {
                bluetoothAdapter.cancelDiscovery()
            }
        }

        val intentFilter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        registerReceiver(receiver, intentFilter)

        deviceList.setOnItemClickListener { _, _, position, _ ->
            val selectedDevice = t.getDevice(position)
            val selectedRssi = t.getDeviceRssi(selectedDevice)

            val connectIntent = Intent(this, Connection::class.java).apply {
                putExtra("EXTRA_DEVICE", selectedDevice)
                putExtra("EXTRA_RSSI", selectedRssi)
            }
            startActivity(connectIntent)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (BluetoothDevice.ACTION_FOUND == intent?.action) {
                val device: BluetoothDevice? =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                device?.let {
                    if (ActivityCompat.checkSelfPermission(
                            context!!,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    }

                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE)
                    val distance = calculateDistance(rssi)
                    t.addDevice(device, rssi)

                    stringArrayList.add("Name: ${device.name}\nAddress: ${device.address}\nRSSI: $rssi dBm\nDistance: $distance m")
                    arrayAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
    }

    protected fun calculateDistance(rssi: Short): Double {
        val base: Double = 10.0
        val RSSI1m = -59.0
        val pathLossExponent = 2.0
        val ratio: Double = (RSSI1m - rssi) / (10 * pathLossExponent)
        return base.pow(ratio)
    }

    private inner class LeDeviceListAdapter : BaseAdapter() {
        private val mLeDevices = mutableListOf<BluetoothDevice>()
        private val mLeDevicesRssi = mutableMapOf<String, Short>()

        fun addDevice(device: BluetoothDevice, rssi: Short) {
            if (!mLeDevices.contains(device)) {
                mLeDevices.add(device)
                mLeDevicesRssi[device.address] = rssi
            } else {
                mLeDevicesRssi[device.address] = rssi
            }
        }

        fun getDevice(position: Int): BluetoothDevice {
            return mLeDevices[position]
        }

        fun getDeviceRssi(device: BluetoothDevice): Short {
            return mLeDevicesRssi[device.address] ?: Short.MIN_VALUE
        }

        fun clear() {
            mLeDevices.clear()
            mLeDevicesRssi.clear()
        }

        override fun getCount(): Int {
            return mLeDevices.size
        }

        override fun getItem(position: Int): Any {
            return mLeDevices[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: layoutInflater.inflate(
                android.R.layout.simple_list_item_1,
                parent,
                false
            )
            val device = getDevice(position)
            val rssi = getDeviceRssi(device)
            val distance = calculateDistance(rssi)

            if (ActivityCompat.checkSelfPermission(
                    /* context = */ this@DiscoverDevices,
                    /* permission = */ Manifest.permission.BLUETOOTH_CONNECT
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                (view as TextView).text =
                    "Name: ${device.name}\nAddress: ${device.address}\nRSSI: $rssi dBm\nDistance: $distance m"
            }
                return view
            }
    }
}