package com.example.bluetooth
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


val REQUEST_ENABLE_BT:Int=1
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        var bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()


        val ButtonON :Button=findViewById(R.id.bton)

//        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        ButtonON.setOnClickListener(){
            if(bluetoothAdapter == null){
                Toast.makeText(this, "Bluetooth is not supported on this device", Toast.LENGTH_SHORT).show();
            }else{
                if( bluetoothAdapter.isEnabled) {
                    if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED) {
                        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                        startActivityForResult(enableBtIntent,REQUEST_ENABLE_BT)

                    }
                }else{
                    Toast.makeText(this, "Please turn Bluetooth on", Toast.LENGTH_SHORT).show();

                }

            }

        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode== REQUEST_ENABLE_BT){
            if(resultCode== RESULT_OK){
                Toast.makeText(this, "Bluetooth is enabled", Toast.LENGTH_SHORT).show()
                val listIntent=Intent(this,DiscoverDevices::class.java)
                startActivity(listIntent)
            }else if(resultCode== RESULT_CANCELED){
                Toast.makeText(this, "Bluetooth cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

