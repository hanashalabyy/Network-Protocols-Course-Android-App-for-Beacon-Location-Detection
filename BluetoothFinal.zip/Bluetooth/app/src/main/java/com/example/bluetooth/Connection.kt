package com.example.bluetooth

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.IOException
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothProfile
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.UUID
import kotlin.math.pow


class Connection : AppCompatActivity() {
    private lateinit var deviceLocationView: DeviceLocationView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connection2)

        val device: BluetoothDevice? = intent.getParcelableExtra("EXTRA_DEVICE")

        val rssi = intent.getShortExtra("EXTRA_RSSI",Short.MIN_VALUE)
        var distance=calculateDistance(rssi.toShort())

        val deviceNameTextView: TextView = findViewById(R.id.device_name)
        val rssiTextView: TextView= findViewById(R.id.device_rssi)
        val distanceTextView: TextView= findViewById(R.id.device_distance)

        val connectB:Button=findViewById(R.id.connect_button)
        var bluetoothGatt: BluetoothGatt? = null

        val bluetoothGattCallback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    val doneIntent=Intent(this@Connection,done::class.java).apply {
                        putExtra("EXTRA_DISTANCE",distance)
                    }
                    startActivity(doneIntent)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.d("ConnectionStatus", "Not Connected to GATT server")                }
            }
        }

        if (device != null) {
            val deviceName = device.name ?: "Unknown Device"
            deviceNameTextView.text = "Device Name: $deviceName"
            rssiTextView.text = "RSSI: $rssi dBm"
            distanceTextView.text = "Distance: $distance m"

            connectB.setOnClickListener() {
                if (ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return@setOnClickListener
                }
                bluetoothGatt = device.connectGatt(this, false, bluetoothGattCallback)

                Toast.makeText(this, "connected to ${device.name}: ", Toast.LENGTH_SHORT).show()
                }

            }
         else {
            Toast.makeText(this, "No device selected", Toast.LENGTH_SHORT).show()
        }

//        val handler = Handler(Looper.getMainLooper())
//        val delayMillis = 5000L // 5 seconds
//        handler.postDelayed(object : Runnable {
//            override fun run() {
////                 Simulate receiving updated distance
//                distance = calculateDistance(rssi) // Example method to get a random distance
//                deviceLocationView.updateDistance(distance)
//                distanceTextView.text = "Distance: $distance m"
//                handler.postDelayed(this, delayMillis)
//            }
//        }, delayMillis)
    }

     fun calculateDistance(rssi: Short): Double {
        val base: Double = 10.0
        val RSSI1m = -59.0
        val pathLossExponent = 2.0
        val ratio: Double = (RSSI1m - rssi) / (10 * pathLossExponent)
        return base.pow(ratio)
    }
}