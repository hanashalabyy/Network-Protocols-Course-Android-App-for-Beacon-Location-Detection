package com.example.bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlin.math.pow

class done : AppCompatActivity() {
    private lateinit var deviceLocationView: DeviceLocationView
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var bluetoothLeScanner: BluetoothLeScanner
    private val handler = Handler(Looper.getMainLooper())
    private val scanPeriod: Long = 5000 // 5 seconds

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_done)

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        bluetoothLeScanner = bluetoothAdapter.bluetoothLeScanner

        val rssiTextView: TextView = findViewById(R.id.device_rssi)
        val distanceTextView: TextView = findViewById(R.id.device_distance)
        val scanBtn: Button = findViewById(R.id.scan_button)
        deviceLocationView = findViewById(R.id.device_location_view)

        scanBtn.setOnClickListener {
            startBleScan(rssiTextView, distanceTextView)
        }
    }

    private fun startBleScan(rssiTextView: TextView, distanceTextView: TextView) {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_SCAN
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        bluetoothLeScanner.startScan(scanCallback(rssiTextView, distanceTextView))
        handler.postDelayed({
            bluetoothLeScanner.stopScan(scanCallback(rssiTextView, distanceTextView))
        }, scanPeriod)
    }

    private fun scanCallback(rssiTextView: TextView, distanceTextView: TextView) = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            super.onScanResult(callbackType, result)
            val rssi = result.rssi
            val distance = calculateDistance(rssi.toShort())
            rssiTextView.text = "RSSI: $rssi dBm"
            distanceTextView.text = "Distance: ${"%.2f".format(distance)} m"
            deviceLocationView.updateDistance(distance)
        }
    }

    private fun calculateDistance(rssi: Short): Double {
        val base: Double = 10.0
        val RSSI1m = -59.0
        val pathLossExponent = 2.0
        val ratio: Double = (RSSI1m - rssi) / (10 * pathLossExponent)
        return base.pow(ratio)
    }
}
