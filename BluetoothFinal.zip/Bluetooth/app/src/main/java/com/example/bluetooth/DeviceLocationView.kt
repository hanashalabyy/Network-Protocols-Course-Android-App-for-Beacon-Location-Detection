package com.example.bluetooth

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View

class DeviceLocationView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val gridSize = 20 // Adjust grid size as needed
    private val paintGrid = Paint().apply {
        color = Color.GRAY
        style = Paint.Style.STROKE
    }
    private val paintPoint = Paint().apply {
        color = Color.RED
        style = Paint.Style.FILL
    }
    private val paintMyLocation = Paint().apply {
        color = Color.BLUE
        style = Paint.Style.FILL
    }

    var distance: Double = 0.0
    var zoomLevel = 1f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        drawGrid(canvas)
        plotDeviceLocation(canvas)
        plotMyLocation(canvas)
    }

    private fun drawGrid(canvas: Canvas) {
        val rows = height / (gridSize).toInt()
        val cols = width / (gridSize).toInt()

        // Draw horizontal lines
        for (i in 0 until rows) {
            canvas.drawLine(
                0f,
                (i * gridSize * zoomLevel).toFloat(),
                width.toFloat(),
                (i * gridSize * zoomLevel).toFloat(),
                paintGrid
            )
        }

        // Draw vertical lines
        for (i in 0 until cols) {
            canvas.drawLine(
                (i * gridSize * zoomLevel).toFloat(),
                0f,
                (i * gridSize * zoomLevel).toFloat(),
                height.toFloat(),
                paintGrid
            )
        }
    }

    private fun plotDeviceLocation(canvas: Canvas) {
        val x = width / 2
        val y = (height / 2) - (distance.toFloat() * gridSize * zoomLevel) // Adjust distance with gridSize

        canvas.drawCircle(x.toFloat(), y, 10f, paintPoint)
        invalidate()
    }

    private fun plotMyLocation(canvas: Canvas) {
        val x = width / 2
        val y = height / 2

        canvas.drawCircle(x.toFloat(), y.toFloat(), 10f, paintMyLocation)
        val label = "Device Location"
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 20f // Adjust text size as needed
            textAlign = Paint.Align.LEFT
        }
        val textWidth = textPaint.measureText(label)
        canvas.drawText(label, x.toFloat() + 20f, y + 5f, textPaint)
    }

    fun updateDistance(newDistance: Double) {
        distance = newDistance
        invalidate() // Redraw the view with the new distance
    }
}
